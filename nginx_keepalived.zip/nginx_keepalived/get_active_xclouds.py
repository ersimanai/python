#!/usr/bin/python

try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET
import zookeeper
import json
import socket
import ConfigParser
def get_zookerper_ip_and_port():
    print 'get_zookerper_ip_and_port'
    tree = ET.ElementTree(file='conf.xml')
    # for elem in tree.iter(tag='flag'):
    zk_elem = tree.getroot()[0]
    try:
        zk_str = zk_elem[4].text
        first_zk_str = zk_str
        if zk_str.find(',') != -1:
            first_zk_str = zk_str.split(',')[0]
        addr = first_zk_str.split(':')[0]
        port = first_zk_str.split(':')[1]
        return addr, port
    except Exception:
        zk_str = zk_elem[3].text
        first_zk_str = zk_str
        if zk_str.find(',') != -1:
            first_zk_str = zk_str.split(',')[0]
        addr = first_zk_str.split(':')[0]
        port = first_zk_str.split(':')[1]
        return addr, port

def DelLastChar(str):
    str_list=list(str)
    str_list.pop()
    return "".join(str_list)
def GetZookeeperIpPort():
	config = ConfigParser.ConfigParser()
	with open("zk.cfg","rw") as cfgfile:
		config.readfp(cfgfile)
	ip=config.get("zk","ip")
	port=config.get("zk","port")
	return ip, port

def GetZnode():
        config = ConfigParser.ConfigParser()
        with open("zk.cfg","rw") as cfgfile:
                config.readfp(cfgfile)
        znode=config.get("zk","addr")
	return znode

def get_active_xclouds_from_zookeeer(addr, port):
    str_connection = "%s:%s" % (addr, port)
    print "str_connection: %s" % str_connection

    znode = GetZnode()
    print 'znode =====%s ' %znode
    zk = zookeeper.init(str_connection)
    return zookeeper.get_children(zk,znode, None)


if __name__ == '__main__':
	ip, port = GetZookeeperIpPort()
	print 'ip: %s, port: %s' % (ip, port)
	nodes = get_active_xclouds_from_zookeeer(ip, port)
	l_fileWriteObj = open("xcloudAddr.txt","w")
	for node in nodes:
		print node
		ip = socket.gethostbyname(node)
		l_fileWriteObj.write(ip)
		l_fileWriteObj.write('\n')

	l_fileWriteObj.close() 
	config = ConfigParser.ConfigParser()
	with open("zk.cfg","rw") as cfgfile:
		config.readfp(cfgfile)
	name=config.get("zk","addr")
	print name
