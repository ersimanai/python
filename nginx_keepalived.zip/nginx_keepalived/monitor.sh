#!/bin/bash

workpath=$PWD
while true
do
    if [ $# -eq 1 ]; then
        {
            if [ "$1" = "xcloud" ]; then
                $workpath/addNewXcloud.sh
            elif [ "$1" = "memory" ]; then
                $workpath/addNewMemory.sh
            fi

            sleep 5
        }
    elif [ $# -eq 0 ]; then
        {
            $workpath/addNewXcloud.sh
            $workpath/addNewMemory.sh
            sleep 5
        }
	fi
done
