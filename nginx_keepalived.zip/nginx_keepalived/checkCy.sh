#!/bin/bash

#copy check_nginx.sh to /etc/init.d/

cp check_nginx.sh /etc/init.d/
