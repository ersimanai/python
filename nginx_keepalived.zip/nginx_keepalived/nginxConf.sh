#########################################################################
# File Name: nginxConf.sh
# Author: yangxiaojun
# mail: yangxiaojun@bonc.com.cn
# Created Time: Wed 27 Sep 2017 05:07:10 PM CST
#########################################################################
#!/bin/bash

workpath=$PWD
cp $workpath/nginx.conff $workpath/nginx.conf
$workpath/start_xcperf.sh

cp $workpath/nginx.conf  $workpath/nginx/conf/

$workpath/addServer.sh
