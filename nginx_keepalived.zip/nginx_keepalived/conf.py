#!/usr/bin/python 
#import zookeeper
import os
import sys
import zookeeper
import json
import socket
import ConfigParser
try:
      import xml.etree.cElementTree as ET
except ImportError:
      import xml.etree.ElementTree as ET

def read_xml(path):
    tree = ET.ElementTree(file='conf.xml')
    return tree.getroot()

def get_ip_port(server):
    zk_znode  = server[1].text
    uport = server[2].text
    xport = server[3].text
    upstream = server[4].text
    str_server = server[0].text

    print 'str_server : %s' %str_server

    count = str_server.count(',')
    print 'count:%d' %count
    
    if count == 0:
        ip = str_server.split(':')[0]
        port = str_server.split(':')[1]
        return ip, port, zk_znode, uport, xport, upstream

    ip_port = str_server.split(',')[0]
    port = ip_port.split(':')[1]
    ip = ip_port.split(':')[0]
    i = 0

    while i < count:
        ip_port = str_server.split(',')[i]
        ip = ip_port.split(':')[0]
        port = ip_port.split(':')[1]
        ping = os.popen('./ip.sh' + ' ' + ip)
        if ping.read() == '3\n':
           return ip, port, zk_znode, uport, xport, upstream
        i = i + 1

    return ip, port, zk_znode, uport, xport, upstream

def get_ip_ports(server):
    zk_znode = server[1].text
    uport = server[2].text
    xport = server[3].text
    upstream = server[4].text
    str_server = server[0].text

    return str_server, zk_znode, uport, xport, upstream

def get_server(servers, server_type):
    if server_type == 'xcloud':
        return servers[0]
    if server_type == 'memory':
        return servers[1]

def get_active_nodes_from_zookeeper(str_server, znode):
    #str_connection = "%s:%s" % (ip, port)
    #print "str_connection: %s" % str_connection
    zk = zookeeper.init(str_server)
    return zookeeper.get_children(zk,znode, None)

def write_xclouds_to_file(nodes, xcloud_file):
    l_fileWriteObj = open(xcloud_file,"w")
    for node in nodes:
        print node
        ip = socket.gethostbyname(node)
        l_fileWriteObj.write(ip)
        l_fileWriteObj.write('\n')
    l_fileWriteObj.close()

def write_memory_to_file(nodes, memory_file):
    l_fileWriteObj = open(memory_file, "w")
    for node in nodes:
        print 'memory_node : %s',node
        ip = node.split(':')[0]
        l_fileWriteObj.write(ip)
        l_fileWriteObj.write('\n')
    l_fileWriteObj.close()

def write_conf_to_file(servers, name='none'):
    print 'name is %s',name
    if name != 'none':
        server = get_server(servers,name)
        str_server = server[0].text
        zk_znode = server[1].text
        uport = server[2].text
        sport = server[3].text
        upstream = server[4].text
        nodes = get_active_nodes_from_zookeeper(str_server,zk_znode)

    if name == 'xcloud':
        l_file_write_xcloud_addrs = open('xcloudAddr.txt', "w")
        for node in nodes:
            print 'xcloud_node:', node
            ip = socket.gethostbyname(node)
            l_file_write_xcloud_addrs.write(ip)
            l_file_write_xcloud_addrs.write('\n')
        l_file_write_xcloud_addrs.close()
        l_file_write_nginx_conf = open('nginxConf', "w")
        l_file_write_nginx_conf.write('x_sport='+sport + '\n')
        l_file_write_nginx_conf.write('x_uport='+ uport + '\n')
        l_file_write_nginx_conf.write('x_upstream='+ upstream + '\n')
        l_file_write_nginx_conf.close()
        return 
    if name == 'memory':
        l_file_write_memory_addrs = open('memoryAddr.txt', "w")
        for node in nodes:
            print 'memory_node:', node
            ip = node.split(':')[0]
            l_file_write_memory_addrs.write(ip)
            l_file_write_memory_addrs.write('\n')
        l_file_write_memory_addrs.close()
        l_file_write_nginx_conf = open('nginxConf', "w")
        l_file_write_nginx_conf.write('m_sport='+sport + '\n')
        l_file_write_nginx_conf.write('m_uport='+ uport + '\n')
        l_file_write_nginx_conf.write('m_upstream='+ upstream + '\n')
        l_file_write_nginx_conf.close()
        return  

    x_server = get_server(servers, 'xcloud')
    x_str_server_addrs = x_server[0].text
    x_zk_znode = x_server[1].text
    x_uport = x_server[2].text
    x_sport = x_server[3].text
    x_upstream = x_server[4].text
    x_nodes = get_active_nodes_from_zookeeper(x_str_server_addrs, x_zk_znode) 

    m_server = get_server(servers, 'memory')
    m_str_server_addrs = m_server[0].text
    m_zk_znode = m_server[1].text
    m_uport = m_server[2].text
    m_sport = m_server[3].text
    m_upstream = m_server[4].text
    m_nodes = get_active_nodes_from_zookeeper(m_str_server_addrs, m_zk_znode)

    l_file_write_xcloud_addrs = open('xcloudAddr.txt', "w")
    for node in x_nodes:
        print 'xcloud_node:%s', node
        ip = socket.gethostbyname(node)
        l_file_write_xcloud_addrs.write(ip)
        l_file_write_xcloud_addrs.write('\n')
    l_file_write_xcloud_addrs.close()

    l_file_write_memory_addrs = open('memoryAddr.txt', "w")
    for node in m_nodes:
        print 'memory_node:%s', node
        l_file_write_memory_addrs.write(node)
        l_file_write_memory_addrs.write('\n')
    l_file_write_memory_addrs.close()

    l_file_write_nginx_conf = open('nginxConf', "w")

    l_file_write_nginx_conf.write('x_sport='+ x_sport + '\n')
    l_file_write_nginx_conf.write('x_uport='+ x_uport + '\n')
    l_file_write_nginx_conf.write('x_upstream='+ x_upstream + '\n')

    l_file_write_nginx_conf.write('m_sport='+ m_sport + '\n')
    l_file_write_nginx_conf.write('m_uport='+ m_uport +'\n')
    l_file_write_nginx_conf.write('m_upstream='+ m_upstream + '\n')

    l_file_write_nginx_conf.close()

def insert_nginxConf(upstream, uport):
    lines = []
    f = open('nginx.conf', 'r')
    for line in f:
        if line.find(upstream) != -1:
            f.close()
            del lines[:]
            return
        lines.append(line)
    f.close()

    print "nginx.conf  lines====", lines;
    inster = upstream + '\n\n' + '}' +'\n' + 'server {\n'+ 'listen  ' + uport + ';\n'+ 'proxy_connect_timeout 3600s;\n'+'proxy_timeout 3600s;\n'+'proxy_pass '+'u_'+uport+';\n}\n'
    lines.insert(17, inster)
    s=''.join(lines)
    f = open('nginx.conf', "w")
    f.write(s)
    f.close()
    del lines[:]


def write_conf_to_files(monitor='none'):
    root = read_xml('conf.xml')

    l_file_write_servers = open('servers.txt', 'w')
    for server in root.findall('server'):
        zk_addr = server.find('zk_server').text
        zk_znode = server.find('zk_znode').text
        uport = server.find('uport').text
        sport = server.find('sport').text
        l_file_write_servers.write(uport+'\n')
        l_file_write_addrs = open('server'+ '_' +uport+'.txt', "w")
        upstream = 'upstream '+'u_'+uport+'{'
	if monitor == 'none':
            insert_nginxConf(upstream, uport)

        nodes = get_active_nodes_from_zookeeper(zk_addr,zk_znode)

        for node in nodes:
            print "addr======", node
            if node.find(':') != -1:
                addr = 'server' + ' '+node + ' '+'max_fails=3  fail_timeout=30;'
                l_file_write_addrs.write(addr+'\n')
                continue
            if node.find('.') != -1 and node.find(':') == -1:
                addr = 'server' + ' ' + node+':' + sport + ' ' + 'max_fails=3  fail_timeout=30;'
                l_file_write_addrs.write(addr +'\n')
                continue
            if node.find('_') != -1:
                node = node.split('_')[0]
                ip = socket.gethostbyname(node)
                #port = node.split('_')[1]
                addr = 'server' + ' ' + ip +':' + sport + ' ' + 'max_fails=3  fail_timeout=30;'
                l_file_write_addrs.write(addr+'\n')
                continue
            
            ip = socket.gethostbyname(node)
            addr = 'server' +' ' + ip + ':' + sport + ' ' + 'max_fails=3  fail_timeout=30;'
            l_file_write_addrs.write(addr+'\n')

        l_file_write_addrs.close()
    
    l_file_write_servers.close()

if __name__ == '__main__':
    if len(sys.argv) == 2:
	print 'argv is ===', sys.argv[1]
    	write_conf_to_files(sys.argv[1])
    if len(sys.argv) == 1:
	write_conf_to_files()
    #servers = read_xml('conf.xml')
    #if len(sys.argv) == 2:
    #    print 'argv is :',sys.argv[1]
    #    write_conf_to_file(servers, sys.argv[1])
    #if len(sys.argv) == 1:
     #   write_conf_to_file(servers)

