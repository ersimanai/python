#!/usr/bin/python

from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer

import urlparse
try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET
import zookeeper
import httplib
import os
# import psutil
import json
import socket

g_memtotal='MemTotal'
g_memfree='MemFree'
g_memxcloud='MemXcloud'

g_cpuCore='cpuCore'
g_cpuUsed='cpuUsed'
g_cpuXcloud='cpuXcloud'

g_sysinfo= '1'
g_expand= 'false'

def server_unavailable_str(addr):
    host_fqdn = socket.getfqdn(addr)
    host_ip = socket.gethostbyname(host_fqdn)
    result = '{' \
             '"host":"%s:%s",' \
             '"monitor_status":"off",' \
             '"cpu":{"cores":"N/A","xcloud_cpu":"N/A","cpuUsed":"N/A"},' \
             '"memory":{"MemTotal":"N/A","MemFree":"N/A","MemXcloud":"N/A"' \
             '}}' % (addr, host_ip)
    return result

def get_zookerper_ip_and_port():
    print 'get_zookerper_ip_and_port'
    tree = ET.ElementTree(file='ds.xml')
    # for elem in tree.iter(tag='flag'):
    zk_elem = tree.getroot()[0]
    try:
        zk_str = zk_elem[4].text
        first_zk_str = zk_str
        if zk_str.find(',') != -1:
            first_zk_str = zk_str.split(',')[0]
        addr = first_zk_str.split(':')[0]
        port = first_zk_str.split(':')[1]
        return addr, port
    except Exception:
        zk_str = zk_elem[3].text
        first_zk_str = zk_str
        if zk_str.find(',') != -1:
            first_zk_str = zk_str.split(',')[0]
        addr = first_zk_str.split(':')[0]
        port = first_zk_str.split(':')[1]
        return addr, port


def get_active_xclouds_from_zookeeer(addr, port):
    str_connection = "%s:%s" % (addr, port)
    print "str_connection: %s" % str_connection
    zk = zookeeper.init(str_connection)
    return zookeeper.get_children(zk, "/XCLOUD/NODESTATE/NODELIST_FRESH", None)


def get_info_remote(addr):
    try:
        print 'going to fetch data from %s' % addr
        port = get_xcperf_port()
        conn = httplib.HTTPConnection(addr, port)
        conn.request('GET', 'index.html?sysinfo=1&expand=false')
        rsp = conn.getresponse()
        return rsp.read()
    except Exception, e:
        print Exception, ":", e
        return server_unavailable_str(addr)

def get_xcperf_port():
    try:
        file = open('xcperf_port', 'r');
        xcperf_port = file.read()
        return int(xcperf_port)
    except Exception:
        return int(10010)

def get_xcloud_pid():
    file = open('../bin/pid', 'r');
    strpid = file.read()
    print 'get_xcloud_pid ret: %s' % strpid
    return int(strpid)

# def make_remote_url(original_url):
#     return original_url


def collect_xcloud_cpu_mem_info():
    return


def collect_xcloud_mem_info(memdict, pid):
    try:
        process = psutil.Process(pid)
        meminfo = process.memory_info()
        # print process.memory_info()
        print "rss: %d Byte" % (meminfo.rss)
        # assert isinstance(rss, object)
        memdict[g_memxcloud] = long(meminfo.rss / 1024)
        return
    except Exception, e:
        memdict[g_memxcloud] = 'N/A'


def collect_sys_mem_info(memdict):
    mem = {}
    f = open("/proc/meminfo")
    lines = f.readlines()
    f.close()
    for line in lines:
        if len(line) < 2: continue
        name = line.split(':')[0]
        var = line.split(':')[1].split()[0]
        mem[name] = long(var)
    memdict[g_memtotal] = mem[g_memtotal]
    memdict[g_memfree] = mem[g_memfree]
    print 'mem_total: %d' % memdict[g_memtotal]
    return

def collect_xcloud_cpu_info(cpudict, pid):
    try:
        process = psutil.Process(pid)
        cpudict[g_cpuXcloud] = process.cpu_percent()
        return
    except psutil.NoSuchProcess:
        cpudict[g_cpuXcloud] = 'N/A'

def collect_sys_cpu_info(cpudict):
    cpudict[g_cpuCore] = psutil.cpu_count()
    cpudict[g_cpuUsed] = psutil.cpu_percent()
    return
# [in]
# [out] string like: "MemTotal" : "65809859", "MemFree" : "50000059", "MemXcloud" : "10000059"
def collect_sys_cpu_mem_info(memdict, cpudict, pid):
    # sys_mem_total = 0;
    # sys_mem_free = 0;
    collect_sys_mem_info(memdict)
    collect_xcloud_mem_info(memdict, pid)
    collect_sys_cpu_info(cpudict)
    collect_xcloud_cpu_info(cpudict, pid)
    print 'mem_total: %d' % memdict[g_memtotal]
    print 'mem_free: %d' % memdict[g_memfree]
    print 'mem_xcloud: %s' % memdict[g_memxcloud]
    print 'cpu_core: %d' % cpudict[g_cpuCore]
    print 'cpu_used: %f' % cpudict[g_cpuUsed]
    print 'cpu_xcloud: %s' % cpudict[g_cpuXcloud]
    # print 'sys_mem_free: ' + sys_mem_free
    return

def parse_url(strurl):
    print 'enter func parse_url'
    print strurl

    global g_sysinfo
    global g_expand
    urldict = urlparse.parse_qs(urlparse.urlparse(strurl).query)

    # g_sysinfo = urldict['sysinfo']
    # g_expand = urldict['expand']

    print urldict['expand']
    for expand in urldict['expand']:
        g_expand = expand

    for sys_info in urldict['sysinfo']:
        g_sysinfo = sys_info

    return


def to_json(data):
    return json.dumps(data)


def to_json_demo():
    jsdata = {"HOSTS" : [{"host" : "172.16.12.59",
                          "memory" : {"MemTotal" : "65809859", "MemFree" : "50000059", "MemXcloud" : "10000059"},
                          "cpu" : {"cores" : "8", "cpuUsed" : "0.59", "xcloud_cpu" : "159.0"}},
                         {"host": "172.16.12.60",
                          "memory": {"MemTotal": "65809860", "MemFree": "50000060", "xcloud_mem": "10000060"},
                          "cpu": {"cores": "8", "cpuUsed": "0.60", "cpuXcloud": "160.0"}}
                         ]}
    return json.dumps(jsdata)


def make_result_single(mem_dict, cpu_dict):
    print "enter func make_result_single"
    host_name = socket.gethostname()
    host_fqdn = socket.getfqdn(socket.gethostname())
    host_ip = socket.gethostbyname(host_fqdn)
    result = '{' \
             '"host":"%s:%s",' \
             '"monitor_status":"on",' \
             '"cpu":{"cores":"%d","xcloud_cpu":"%s","cpuUsed":%s},' \
             '"memory":{"MemTotal":"%d","MemFree":"%d","MemXcloud":"%s"' \
             '}}' % \
             (host_name, host_ip,
              cpu_dict[g_cpuCore], cpu_dict[g_cpuXcloud], cpu_dict[g_cpuUsed],
              mem_dict[g_memtotal], mem_dict[g_memfree], mem_dict[g_memxcloud])
    print result
    return result

def make_result_total(results):
    print 'enter func make_result_total'

    len_results = len(results)
    index = 0
    result_total = ''
    if g_expand == 'true':
        result_total += '{"HOSTS":['
        for result in results:
            result_total += result
            index = index + 1
            print 'compare index : %i , len_results : %i' % (index, len_results)
            if (index != len_results):
                result_total += ','
        result_total+=']}'
    else:
        for result in results:
            result_total += result
    return result_total

# Create custom HTTPRequestHandler class
class KodeFunHTTPRequestHandler (BaseHTTPRequestHandler):
    # handle GET command
    def do_GET(self):
        if self.path.endswith("/favicon.ico"):
            self.send_response(404)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            return
        try:
            # send code 200 response
            print self.path
            parse_url(self.path)
            self.send_response(200)

            # send header first
            self.send_header('Content-type', 'text-html')
            self.end_headers()

            memlist = [(g_memtotal, 0), (g_memfree, 0), (g_memxcloud, 0)]
            memdict = dict(memlist)
            cpulist = [(g_cpuCore, 0), (g_cpuUsed, 0), (g_cpuXcloud, 0)]
            cpudict = dict(cpulist)

            result_list = []
            pid = get_xcloud_pid()
            if g_sysinfo:
                collect_sys_cpu_mem_info(memdict, cpudict, pid)
                result = make_result_single(memdict, cpudict)
                result_list.append(result)

            # if g_expand == 'true':
            if g_expand == 'true':
                addr, port = get_zookerper_ip_and_port()
                print addr 
                print port
                # print 'get zookeeper ip, port from ds.xml: %s : %s' % addr, port

                print 'fetch active xclouds from zookeeper:'
                active_nodes = get_active_xclouds_from_zookeeer(addr, port)
                print active_nodes

                host_name = socket.gethostname()
                host_fqdn = socket.getfqdn(socket.gethostname())
                host_ip = socket.gethostbyname(host_fqdn)
                print 'host_name: %s:%s' % (host_name, host_ip)
                for node in active_nodes:
                    if node == host_name:
                        continue
                    else:
                        str_result = get_info_remote(node)
                        print str_result
                        result_list.append(str_result)

            data = make_result_total(result_list)
            print data
            # send file content to client
            # jsdata = to_json_demo()
            # jsdata = to_json(data)
            # print jsdata
            self.wfile.write(data)
            return

        except IOError:
            self.send_error(404, 'file not found')


def run():
    print('http server is starting...')

    # ip and port of servr
    # by default http server port is 80
    host_fqdn = socket.getfqdn(socket.gethostname())
    host_ip = socket.gethostbyname(host_fqdn)
    port = get_xcperf_port()
    server_address = (host_ip, port)
    httpd = HTTPServer(server_address, KodeFunHTTPRequestHandler)
    print('http server is running...')
    httpd.serve_forever()


if __name__ == '__main__':
	ip, port = get_zookerper_ip_and_port()
	print 'ip: %s, port: %s' % (ip, port)
	get_active_xclouds_from_zookeeer(ip, port)
