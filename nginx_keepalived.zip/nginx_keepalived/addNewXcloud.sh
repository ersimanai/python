#!/bin/bash
set -e
if [ $# == 0 ]; then
    ./start_xcperf.sh
elif [ $# == 1 ]; then
    ./start_xcperf.sh $1
fi

workpath=$PWD
nginx=$workpath/nginx/sbin/nginx
nginxConf=$workpath/nginx/conf/nginx.conf
newAddr=xcloudAddr.txt
portFile=neededConf.txt
 

echo "nginx=$nginx  , nginxConf=$nginxConf,    newAddr=$newAddr,    portFile=$portFile"

upstream_x=`sed -n '2p' "$portFile"`

echo "upstream_x is $upstream_x"

startNu=$(sed -n "/$upstream_x/=" $nginxConf)

let startNu=startNu+1

endNu=$(sed -n "/#mark_line/=" $nginxConf)

num=0

if [ $endNu -gt $startNu ];then
    let num=endNu-startNu
fi


let endNu=endNu-1

newNum=$(sed -n '$=' $newAddr)

echo "newNum:$newNum"
echo "num:$num"

server=`sed -n '3p' "$portFile"`
port=`sed -n '1p' "$portFile"`

maohao=":"
. nginxConf 

funcUpdate() {
	cat $newAddr | while read aline
	do
		insert=${server}${aline}${maohao}${x_sport}${port} 
		echo "we will insert xcloudServer is : $insert"
	    sed -i "/$upstream_x/a $insert" $nginxConf
	done
}

funcDelete() {
	if [ $endNu -eq $startNu ]; then #is arg1 equal arg2?
		echo "we will delete $starNu"
		sed -i "$startNu d" $nginxConf
	elif [ $endNu -gt $startNu ]; then #arg1 > arg2
		echo "we will delete $startNu to $endNu from $nginxConf"
		sed -i "$startNu,$endNu d" $nginxConf
	else
		echo "deleted"
	fi

	echo "endNu:$endNu,startNu:$startNu"
}


#oldServer=`sed -n "$num p" "$nginxConf"`
if [ $newNum -gt $num ] ; then
	funcDelete
	funcUpdate
fi
if [ $num -gt $newNum ] ; then
        funcDelete
        funcUpdate
fi



echo "the number of nginx.conf is equal addrs from zookeeper"

if [ $newNum -eq $num ]; then
    cat $newAddr | while read line
    do
        addr=${server}${line}${maohao}${x_sport}${port}
        echo "要从nginx.conf中搜索的地址是$addr"
        grep -q "$addr"  $nginxConf &&
            {
                echo "exists $addr"
                continue
            } ||
            {
                echo "$addr is not exists in $nginxConf"
                funcDelete
                funcUpdate
                break
            }  
    done
fi


$nginx -s reload
