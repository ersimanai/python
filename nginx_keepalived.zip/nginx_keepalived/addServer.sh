#########################################################################
# File Name: addServer.sh
# Author: yangxiaojun
# mail: yangxiaojun@bonc.com.cn
# Created Time: Wed 27 Sep 2017 11:19:54 AM CST
#########################################################################
#!/bin/bash
set -e
workpath=$PWD
nginxconf=$workpath/nginx/conf/nginx.conf
servers=$workpath/servers.txt
nginxnewconf=$workpath/nginxnew.conf
nginxconf=$workpath/nginx/conf/nginx.conf

if [ $# -eq 1 ];then
    $workpath/start_xcperf.sh $1
elif [ $# -eq 0 ];then
    $workpath/start_xcperf.sh
fi

function updateAddr() {
    echo "updateAddr-----------------"
    echo "will inster $1 to $3 where $2"
    cat $1 | while read line
    do
        sed -i "/$2/a $line" $3
    done
}

function deleteAddr() {
    echo "deleteAddr-------------------"
    if [ $2 -eq $1 ];then
        echo "we will delete $1 from  $3"
        sed -i "$1 d" $3
    elif [ $2 -gt $1 ];then
        echo "we will delete $1 to $2 from $3"
        sed -i "$1,$2 d" $3
    else
        echo "deleted"
    fi
}

function check() {
    echo "check------------------"
    cat $5 | while read line
    do
	echo "ckeck line is =====$line,and check file is ===$5 from $3"
        grep -q "${line}" $3 &&
            {
                echo "exists $line"
                continue
            } ||
            {
                echo "$line is not exists in $3"
                deleteAddr $1 $2 $3
                updateAddr $5 $4 $3
                break
            }
    done
}

cat $servers | while read line
do
    upstream='upstream u_'$line
    listen='listen  '$line';'
    addrfile='server_'$line'.txt'
    echo "upstream:$upstream,listen:$listen,addrfile=$addrfile"
    where='u_'$line'{'
    upstreamNu=$(sed -n "/$upstream/=" $nginxconf)
    let startNu=$upstreamNu+1 
    listenNu=$(sed -n "/$listen/=" $nginxconf)
    let endNu=$listenNu-2
    echo "upstreamNu:$upstreamNu, listenNu:$listenNu,endNu=$endNu,startNu=$startNu"

    num=0
    newNu=0
    if [ $endNu -gt $startNu ];then
        let num=endNu-startNu
        let endNu=endNu-1
    fi

    newAddr=$workpath/'server_'$line'.txt'
    newNu=$(sed -n '$=' $newAddr)
    
    echo "newNu=$newNu,num=$num,newAddr=$newAddr"

    if [ $newNu -eq $num ];then
       check $startNu $endNu $nginxconf $where $newAddr
    else
        deleteAddr $startNu $endNu $nginxconf
        updateAddr $newAddr $where $nginxconf
    fi




done

