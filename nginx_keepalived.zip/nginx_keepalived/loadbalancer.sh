#!/bin/bash
set -e
workpath=$PWD
restart() {
	echo " restart"
	nohup $workpath/nginx/sbin/nginx -s reload
	nohup $workpath/keepalived.sh restart
}

stop () {
	echo " stop"
    $workpath/nginx/sbin/nginx -s stop
    pkill monitor.sh
    rm -rf $workpath/*.txt
    rm -rf $workpath/nohup.out
}

start () {
	echo " start"
	A=`find /etc/init.d/  -name check_nginx.sh | wc -l`
	if [ $A -eq 0 ]; then
		cp check_nginx.sh /etc/init.d/
	fi
	nohup $workpath/nginx/sbin/nginx
	nohup $workpath/keepalived.sh start
	
}

startMonitor() {
    A=`grep "x_sport" nginxConf | wc -l`
    B=`grep "m_uport" nginxConf | wc -l`

    if [ $A -eq 1 ]; then
        if [ $B -eq 0 ]; then
            nohup $workpath/monitor.sh xcloud &
        elif [ $B -eq 1 ]; then
            nohup  $workpath/monitor.sh &
        fi
    elif [ $A -eq 0 ]; then
        if [ $B -eq 1 ]; then
            nohup $workpath/monitor.sh memory &
        fi
    fi
}

monitor() {
    nohup $workpath/monitor.sh &
}

remonitor() {
   B=`ps -C monitor.sh --no-header | wc -l`

  if [ $B -eq 0 ];then
     monitor
 fi 
}

case "$1" in
	start)
		start
        #startMonitor
        monitor
		;;
	stop)
		stop
		;;
	restart)
		restart
        #startMonitor
        remonitor
		;;
	reload)
		restart
        #startMonitor
        remonitor
		;;
	status)
		A=`ps -C nginx --no-header | wc -l`
		if [ $A -eq 0 ]; then
			echo "nginx:faild"
		else
			echo "nginx:success"
		fi
		B=`ps -C monitor.sh --no-header | wc -l`
		if [ $B -eq 0 ]; then
			echo "monitor:faild"
		else
			echo "monitor:success"
		fi
		C=`ps -C keepalived --no-header | wc -l`
		if [ $C -eq 0 ]; then
			echo "keepalived:faild"
		else
			echo "keepalived:success"
		fi
		;;
	*)
		echo "Usage: $0{start|stop|restart|reload|status}"
esac


