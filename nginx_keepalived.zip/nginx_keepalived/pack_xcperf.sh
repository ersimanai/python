pyinstaller xcperf.py

cp -r dist/xcperf/ xcperf

cp libzookeeper_mt.so.2.0.0 xcperf
cp zookeeper.so xcperf

cp start_xcperf.sh xcperf
