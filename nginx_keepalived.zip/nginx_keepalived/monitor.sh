#!/bin/bash

workpath=$PWD
function sizef() {
    return du -b $1 | awk '{print int($1/1024)}'
}

while true
do
    if [ $# -eq 1 ]; then
        {
            if [ "$1" = "xcloud" ]; then
                $workpath/addNewXcloud.sh $1
            elif [ "$1" = "memory" ]; then
                $workpath/addNewMemory.sh $1
            fi

            sleep 5
        }
    elif [ $# -eq 0 ]; then
        {
            #$workpath/addNewXcloud.sh xcloud
            #$workpath/addNewMemory.sh memory
            #$workpath/addNewServers.sh
            $workpath/addServer.sh monitor
	    sizeno=$(du -b $workpath/nohup.out | awk '{print int($1/1024)}')
	    echo "size is $sizeno"
	    if [ $sizeno -gt  1024000 ];then
		echo "nohup.out is too big, truncated it"
		>$workpath/nohup.out
	    fi
	    sizelog=$(du -b $workpath/nginx/logs/error.log | awk '{print int($1/1024)}')
	    echo "nginxLog is $sizelog"
	    if [ $sizelog -gt 1024000 ];then
		echo "nginxLog is too big, truncated it"
		>$workpath/nginx/logs/error.log
	    fi
            sleep 5
        }
	fi
done
