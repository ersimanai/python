#########################################################################
# File Name: stest.sh
# Author: yangxiaojun
# mail: yangxiaojun@bonc.com.cn
# Created Time: Wed 27 Sep 2017 11:08:46 AM CST
#########################################################################
#!/bin/bash
workpath=$PWD
file=$workpath/'server_32431.txt'
num=$(sed -n '$=' $file)
echo "num===$num"
