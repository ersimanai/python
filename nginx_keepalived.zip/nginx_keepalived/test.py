#!/usr/bin/python 
import os
import sys
import re



def test():
    upstream = 'upstream ' + 'u_32431{'
    lines = []
    print len(lines)
    s = ''
    with open('nginxnew.conf') as file:
        for line in file:
            #print 'line   is ',line

            if line.find('\n') != -1:
                line = line.split('\n')[0]
            if line == upstream:
                s = 's'
                continue
                print upstream
            if s == 's':
                lines.append(line)
            if s == 's' and line == '}':
                break

    print lines 
    print len(lines)
    print lines[0]
    linesT = []
    linesT.append('ddddd')
    print len(linesT)


if __name__ == '__main__':
    test()
    f = open('nginxnew.conf')
    for line in f.readlines():
        if  re.match("server 172.16.12.9:3334 max_fails=3 fail_timeout=30;", line):
            print "match"
            print line
            del line
