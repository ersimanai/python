echo `dirname $0`
workpath=$PWD
cd `dirname $0`
# export LD_PRELOAD=`dirname $0`/libzookeeper_mt.so.2.0.0:$LD_PRELOAD
export LD_PRELOAD=./libzookeeper_mt.so.2.0.0:$LD_PRELOAD

# ./xcperf &

#`touch xcloudAddr.txt`
#`chmod 666 xcloudAddr.txt`
#python get_active_xclouds.py
# `dirname $0`/xcperf
if [ $# == 1 ];then
    $workpath/conf.py $1
    exit 0
fi
./conf.py 
