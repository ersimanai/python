#!/usr/bin/python 

import os
import sys
import json
import zookeeper
import socket
import ConfigParser
import re
try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

def get_active_nodes_from_zookeeper(str_server, znode):
    zk = zookeeper.init(str_server)
    return zookeeper.get_children(zk, znode, None)

def read_xml(path):
    tree = ET.ElementTree(file='conf.xml')
    return tree.getroot()

def write_conf_files():
    root = read_xml('conf.xml')

    for server in root.findall('server'):
        zk_addr = server.find('zk_server').text
        zk_znode = server.find('zk_znode').text
        uport = server.find('uport').text
        sport = server.find('sport').text

        upstream = 'upstream ' + 'u_' + uport + '{'
        linesConf = []
        linesAdd = []
        s = ' '
        nodes = get_active_nodes_from_zookeeper(zk_addr, zk_znode)

        print "upstream------", upstream
        with open('nginxnew.conf') as file:
            for line in file:
                if line.find('\n') != -1:
                    line = line.split('\n')[0]
                if line is upstream:
                    s = 's'
                    continue
                if s is 's' and line is not '}':
                    linesConf.append(line)
                if line is '}' and  s is 's':
                    s = ' '
                    break

        for node in nodes:
            print "node======", node
            if node.find(':') != -1:
                addr = 'server' + ' '+node + ' '+'max_fails=3  fail_timeout=30;'
                print "addr1", addr
            elif node.find('.') != -1 and node.find(':') == -1:
                addr = 'server' + ' ' + node+':' + sport + ' ' + 'max_fails=3  fail_timeout=30;'
                print "addr2", addr
            elif node.find('_') != -1:
                node1 = node.split('_')[0]
                ip = socket.gethostbyname(node1)
                port = node1.split('_')[1]
                addr = 'server' + ' ' + ip +':' + port + ' ' + 'max_fails=3  fail_timeout=30;'
                print "addr3", addr
            else:
                ip = socket.gethostbyname(node)
                addr = 'server'+' '+ip+':'+sport+' '+'max_fails=3  fail_timeout=30;'
                print "addr4", addr

            for line in linesConf:
                print "line", line
                if line == addr:
                    print "del addr===,", addr
                    linesConf.remove(line)
                    continue
                print "add addr===,", addr
                linesAdd.append(addr)

            


if __name__ == '__main__':
    write_conf_files()
