#!/bin/bash
set -e
if [ $# == 0 ]; then
    ./start_xcperf.sh
elif [ $# == 1 ]; then
    ./start_xcperf.sh $1
fi

workpath=$PWD
nginx=$workpath/nginx/sbin/nginx
nginxConf=$workpath/nginx/conf/nginx.conf
newAddr=xcloudAddr.txt
memAddr=memoryAddr.txt
portFile=neededConf.txt
 

echo "nginx=$nginx  , nginxConf=$nginxConf,    newAddr=$newAddr,    portFile=$portFile"

upstream_x=`sed -n '2p' "$portFile"`
upstream_m=`sed -n '4p' "$portFile"`

echo "upstream_m is $upstream_m"
echo "upstream_x is $upstream_x"

startNu=$(sed -n "/$upstream_x/=" $nginxConf)
m_startNu=$(sed -n "/$upstream_m/=" $nginxConf)

let startNu=startNu+1
let m_startNu=m_startNu+1

endNu=$(sed -n "/#mark_line/=" $nginxConf)
m_endNu=$(sed -n "/#mark_memory/=" $nginxConf)

num=0
m_num=0

if [ $endNu -gt $startNu ];then
    let num=endNu-startNu
fi

if [ $m_endNu -gt $m_startNu ]; then
    let m_num=m_endNu-m_startNu
fi

let m_endNu=m_endNu-1
let endNu=endNu-1

newNum=$(sed -n '$=' $newAddr)
m_newNum=$(sed -n '$=' $memAddr)

echo "newNum:$newNum"
echo "num:$num"
echo "m_newNum:$m_newNum"
echo "m_num:$m_num"

server=`sed -n '3p' "$portFile"`
port=`sed -n '1p' "$portFile"`

maohao=":"
. nginxConf 

funcUpdate() {
	cat $newAddr | while read aline
	do
		insert=${server}${aline}${maohao}${x_sport}${port} 
		echo "we will insert xcloudServer is : $insert"
	    sed -i "/$upstream_x/a $insert" $nginxConf
	done
}

funcDelete() {
	if [ $endNu -eq $startNu ]; then #is arg1 equal arg2?
		echo "we will delete $starNu"
		sed -i "$startNu d" $nginxConf
	elif [ $endNu -gt $startNu ]; then #arg1 > arg2
		echo "we will delete $startNu to $endNu from $nginxConf"
		sed -i "$startNu,$endNu d" $nginxConf
	else
		echo "deleted"
	fi

	echo "endNu:$endNu,startNu:$startNu"
}

funcUpdateMemory() {
    cat $memAddr | while read aline
    do
        #insert=${server}${aline}${maohao}${m_sport}${port}
        insert=${server}${aline}${port}

        echo "we will insert memServer is :$insert"
        sed -i "/$upstream_m/a $insert" $nginxConf
    done
}

funcDeleteMemory() {
    if [ $m_endNu -eq $m_startNu  ]; then
        echo "we will delete $m_startNu"
        sed -i "$m_startNu d" $nginxConf
    elif [ $m_endNu -gt $m_startNu  ]; then
        echo "we will delete $m_startNu to $m_endNu from $nginxConf"
        sed -i "$m_startNu,$m_endNu d" $nginxConf
    else
        echo "delete"
    fi

    echo "m_endNu:$m_endNu, m_startNu:$m_startNu"
}

#oldServer=`sed -n "$num p" "$nginxConf"`
if [ $newNum -gt $num ] ; then
	funcDelete
	funcUpdate
fi
if [ $num -gt $newNum ] ; then
        funcDelete
        funcUpdate
fi

if [ $m_newNum -gt $m_num ];then
    funcDeleteMemory
    funcUpdateMemory
fi
if [ $m_num -gt $m_newNum ]; then
    funcDeleteMemory
    funcUpdateMemory
fi


echo "the number of nginx.conf is equal addrs from zookeeper"

if [ $newNum -eq $num ]; then
    cat $newAddr | while read line
    do
        addr=${server}${line}${maohao}${x_sport}${port}
        echo "要从nginx.conf中搜索的地址是$addr"
        grep -q "$addr"  $nginxConf &&
            {
                echo "exists $addr"
                continue
            } ||
            {
                echo "$addr is not exists in $nginxConf"
                funcDelete
                funcUpdate
                break
            }  
    done
fi

if [ $m_newNum -eq $m_num ]; then
    cat $memAddr | while read line
    do
        #addr=${server}${line}${maohao}${m_sport}${port}
        addr=${server}${line}${port}

        echo "要从nginx.conf中搜索的地址是$addr"
        grep -q "$addr" $nginxConf &&
            {
                echo "exists $addr"
                continue
            }||
            {
                echo "$addr is not exists in $nginxConf"
                funcDeleteMemory
                funcUpdateMemory
                break
            }
    done
fi
#cat $newAddr | while read line
#do
#	addr=${server}${line}${maohao}${x_sport}${port}
#	echo "要从nginx.conf中搜索的地址是$addr"
#	grep -q "$addr"  $nginxConf &&
#	{
#		echo "exists $addr"
#		continue
#	} ||
#	{
#		echo "$addr is not exists in $nginxConf"
#
#		funcDelete
#		funcUpdate
#
#		break
#
#	}
#done

$nginx -s reload
