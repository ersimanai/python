#!/bin/bash

set -e 

# tar xvf *.tar.gz
tar -xvf nginx-1.9.3.tar.gz
tar -xvf keepalived-1.2.24.tar.gz

workpath=$PWD

#install nginx

cd $workpath/nginx-1.9.3
./configure --prefix=$workpath/nginx --with-stream --without-http_rewrite_module
#./configure --with-stream --without-http_rewrite_module
make -j 
make install -j
#cp $workpath/nginx.conf $workpath/nginx/conf/

#install keepalived

cd $workpath/keepalived-1.2.24
./configure --prefix=$workpath/keepalived 
make -j && make install -j


