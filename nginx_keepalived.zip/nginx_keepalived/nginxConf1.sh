#!/bin/bash
set -e
workpath=$PWD

confNginx=$workpath/nginx.conf
#. $workpath/nginxConf 

listen="listen"
space="  "
fenhao=";"
doubleT="       "
x_listen=${listen}${space}${x_uport}${fenhao}
m_listen=${listen}${space}${m_uport}${fenhao}

if [ $# == 1 ];then
    $workpath/start_xcperf.sh $1
    . $workpath/nginxConf
    x_listen=${listen}${space}${x_uport}${fenhao}
    m_listen=${listen}${space}${m_uport}${fenhao}

    if [ "$1" = "xcloud" ]; then
        echo "x_listen = $x_listen"
        server_x=`grep "mark_xserver" $confNginx`
        echo "server_x = $server_x"
        x_Nu=$(sed -n '/mark_xserver/=' $confNginx)
        let x_Nu=x_Nu+1
        sed -i "$x_Nu d" $confNginx
        sed -i "/$server_x/a $x_listen" $confNginx
    fi
    if [ "$1" = "memory" ]; then
        echo "m_listen = $m_listen"
        server_m=`grep "mark_mserver" $confNginx`
        echo "server_m = $server_m"
        m_Nu=$(sed -n '/mark_mserver/=' $confNginx)
        let m_Nu=m_Nu+1
        sed -i "$m_Nu d" $confNginx
        sed -i "/$server_m/a $m_listen" $confNginx
    fi
    
    cp $workpath/nginx.conf   nginx/conf/
    exit 0
fi

$workpath/start_xcperf.sh
. $workpath/nginxConf
m_listen=${listen}${space}${m_uport}${fenhao}
x_listen=${listen}${space}${x_uport}${fenhao}
echo "x_listen = $x_listen"
echo "m_listen = $m_listen"

server_x=`grep "mark_xserver" $confNginx`
server_m=`grep "mark_mserver" $confNginx`

echo "server_x = $server_x"
echo "server_m = $server_m"

x_Nu=$(sed -n '/mark_xserver/=' $confNginx)
m_Nu=$(sed -n '/mark_mserver/=' $confNginx)
let x_Nu=x_Nu+1

sed -i "$x_Nu d" $confNginx
sed -i "$m_Nu d" $confNginx

sed -i "/$server_x/a $x_listen" $confNginx
sed -i "/$server_m/a $m_listen" $confNginx
#cp $workpath/nginx.conf   $workpath/nginx/conf/
cp $workpath/nginxnew.conf $workpath/nginx/conf/
